By using this information and/or downloading the software/code, you agree to cite/acknowledge
Prof. Ahmet Yildiz, University of California, Berkeley, CA 94720, 
in all publications that describe any work that used or was made possible by this program.